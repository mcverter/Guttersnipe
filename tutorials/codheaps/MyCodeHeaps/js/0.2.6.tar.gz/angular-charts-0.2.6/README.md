angular-charts
==============

angular directives for common charts using d3, for more information visit

http://chinmaymk.github.io/angular-charts/

###Contributors
* [michalochman](https://github.com/michalochman) - [configurable colors](https://github.com/chinmaymk/angular-charts/commits?author=michalochman)
* [reneolivo](https://github.com/reneolivo) - fix for [bower.json](https://github.com/chinmaymk/angular-charts/commits?author=reneolivo)

License - MIT.

###Got suggestions ?
Feel free to submit a pull request, file an issue, or get in touch on twitter [@_chinmaymk](https://twitter.com/_chinmaymk)
