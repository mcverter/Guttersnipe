(function (angular, app) {
  'use strict';
  app.controller('UserSettingsCtrl', [function () {

    }]);
}) (window.angular, window.novantas);