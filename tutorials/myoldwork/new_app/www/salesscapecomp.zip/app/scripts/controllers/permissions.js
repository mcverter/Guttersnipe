(function (angular, app) {
  'use strict';
  app.controller('PermissionsCtrl', ['$scope', '$log',
    function ($scope, $log) {

    }]);
}) (window.angular, window.novantas);