if (self.CavalryLogger) { CavalryLogger.start_js(["mle89"]); }

__d('shouldWNSRenderToRHC',['ge'],(function a(b,c,d,e,f,g){'use strict';function h(){return !!c('ge')('fbRHCVideoWNS-root');}f.exports=h;}),null);