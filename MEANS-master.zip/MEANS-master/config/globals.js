module.exports.globals = {
	_: true,
	async: true,
	sails: true,
	services: true,
	models: true
};
