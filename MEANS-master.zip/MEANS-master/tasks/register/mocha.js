module.exports = function (grunt) {
    grunt.registerTask('test', [
        'mochaTest:unit'

    ]);
};
