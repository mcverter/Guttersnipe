contribute-to-MEANS
======================

### How do I add a new MEANS?

1. Fork this repository.
2. Add new features on the fork with tests
3. When finished, send a pull request to this repository.  One of the moderators will check it out, make sure it works, provide feedback, and potentially suggest some tweaks.
4. When everything is rock-solid, we'll add your code as a new repository in this Github organization, and give you admin access so you can make edits, add other committers, close issues, merge pull requests, etc.

Thanks for contributing!
~John & Oscar


# Roadmap

The MEANS project is still in an beta stage. 
> + Please tweet [@sailsjs](https://twitter.com/sailsjs) with any ideas/comments/questions about this repo.


# License

MIT