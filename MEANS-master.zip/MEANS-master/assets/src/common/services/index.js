angular.module('services', [
	'services.config',
	'services.utils',
	'services.title'
]);